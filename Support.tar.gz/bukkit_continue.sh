cd bukkit_and_Spigot_Getter
echo "This is the property of Spigot MC (www.spigotmc.org)"
java -jar BuildTools.jar
cd ..
echo Done!