cd ./Executable_Basic_Server
./start.sh

