cd ./CraftBukkit_Server
start.sh