

echo Bukkit Starter Kit 2>&1 | tee -a ./BSKlog.log
echo From http://skits.businesscatalyst.com 2>&1 | tee -a ./BSKlog.log
echo Issues? Vist http://skits.businesscatalyst.com 2>&1 | tee -a ./BSKlog.log
date 2>&1 | tee -a BSKlog.log
echo -------------------------- 2>&1 | tee -a ./BSKlog.log
echo Preparing 2>&1 | tee -a ./BSKlog.log
echo -------------------------- 2>&1 | tee -a ./BSKlog.log
echo 2>&1 | tee -a ./BSKlog.log

echo 2>&1 | tee -a ./BSKlog.log
echo Making directorys 2>&1 | tee -a ./BSKlog.log
echo 2>&1 | tee -a ./BSKlog.log
mkdir -v ./bin 2>&1 | tee -a ./BSKlog.log

mkdir -v ./SupportDownloads 2>&1 | tee -a ./BSKlog.log

mkdir -v ./Bukkit_and_Spigot_Getter 2>&1 | tee -a ./BSKlog.log

mkdir -v ./CraftBukkit_Server 2>&1 | tee -a ./BSKlog.log

mkdir -v ./Spigot_Server 2>&1 | tee -a ./BSKlog.log

mkdir -v ./Executable_Basic_Server 2>&1 | tee -a ./BSKlog.log

mkdir -v ./Java_Basic_Server 2>&1 | tee -a ./BSKlog.log

mkdir -v ./logs 2>&1 | tee -a ./BSKlog.log

mkdir -v ./bin/Checks 2>&1 | tee -a ./BSKlog.log

mkdir -v ./bin/Extracts 2>&1 | tee -a ./BSKlog.log

mkdir -v ./SupportDownloads/Extracts 2>&1 | tee -a ./BSKlog.log

mkdir -v ./bin/plugins 2>&1 | tee -a ./BSKlog.log

echo
echo Downloading Dependences... 2>&1 | tee -a ./BSKlog.log
echo 2>&1 | tee -a ./BSKlog.log
echo All files saved @ ./SupportDownloads 2>&1 | tee -a ./BSKlog.log
echo 2>&1 | tee -a ./BSKlog.log

echo Downloading Support.zip @ skits.businesscatalyst.com/assets/BukkitStarterKit/Support.zip 2>&1 | tee -a ./BSKlog.log
curl "http://skits.businesscatalyst.com/assets/BukkitStarterKit/Support.zip" -o ./SupportDownloads/Support.zip 2>&1 | tee -a ./BSKlog.log
echo 2>&1 | tee -a ./BSKlog.log

mkdir ./SupportDownloads/Extarcts/Support 2>&1 | tee -a ./BSKlog.log
echo Unzipping... 2>&1 | tee -a ./BSKlog.log
unzip ./SupportDownloads/Support.zip -d ./SupportDownloads/Extracts/Support 2>&1 | tee -a ./BSKlog.log
echo 2>&1 | tee -a ./BSKlog.log
echo Copying to ./bin/Extracts 2>&1 | tee -a ./BSKlog.log
cp -avr ./SupportDownloads/Extracts/Support ./bin/Extracts 2>&1 | tee -a ./BSKlog.log
echo Copying into bin 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Extracts/Support/StarterKit.sh ./bin/StarterKit.sh 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Extracts/Support/BuildToolsrester.sh ./bin/BuildToolsrester.sh 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Extracts/Support/bukkit_and_spigot_getter.sh ./bin/bukkit_and_spigot_getter.sh 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Extracts/Support/restter.sh ./bin/restter.sh 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Extracts/Support/StarterKit_no_bukkit.sh ./bin/StarterKit_no_bukkit.sh 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Extracts/Support/Updatergetter.sh ./bin/Updatergetter.sh 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Extracts/Support/Updates.txt ./bin/Updates.txt 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Extracts/Support/Updater_no_bin.sh ./bin/Updater_no_bin.sh 2>&1 | tee -a ./BSKlog.log
cp -v ./bin/Updater_no_bin.sh ./Updater.sh 2>&1 | tee -a ./BSKlog.log
cp -avr ./bin/Extracts/Support/Checks ./bin 2>&1 | tee -a ./BSKlog.log
cp -avr ./bin/Extracts/Support/ServerFiles ./bin 2>&1 | tee -a ./BSKlog.log
echo Done! 2>&1 | tee -a ./BSKlog.log
echo Running... 2>&1 | tee -a ./BSKlog.log
read -p "Press enter to contnue...." 2>&1 | tee -a ./BSKlog.log
./bin/StarterKit.sh



cp ./BSKlog.log ./logs/`date +%y%m%d`.log 2>&1 | tee -a ./BSKlog.log
