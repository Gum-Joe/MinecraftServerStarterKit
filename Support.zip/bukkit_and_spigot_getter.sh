
echo Getting Bukkit and Spigot... 2>&1 | tee -a ./BSKlog.log
echo Attention! Attention! | tee -a ./BSKlog.log
echo This could take up to 30 minutes! | tee -a ./BSKlog.log
echo Exit out of this windows if you do not want this and run RUNMEnogetter.sh from this windows! | tee -a ./BSKlog.log
read -p "Press any key to continue or exit out of this window....." 2>&1 | tee -a ./BSKlog.log
cd ./Bukkit_and_Spigot_Getter
date 2>&1 | tee -a ./BSKlog.log
java -jar BuildTools.jar 2>&1 | tee -a ./BSKlog.log
echo 2>&1 | tee -a ./BSKlog.log
echo ----------------- 2>&1 | tee -a ./BSKlog.log
echo Time taken: 2>&1 | tee -a ./BSKlog.log
time 2>&1 | tee -a ./BSKlog.log
echo ----------------- 2>&1 | tee -a ./BSKlog.log
echo 2>&1 | tee -a ./BSKlog.log