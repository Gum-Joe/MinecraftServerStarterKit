echo Bukkit Starter kit v1.1 BETA build 47
echo From http://skits.businesscatalyst.com
echo Issues? Vist http://skits.businesscatalyst.com
date
echo

echo ---------------------------------
echo Backing up
echo ---------------------------------
echo
mkdir ./Backup
cp -v ./BSKlog.log ./Backup/BSKlog.log
cp -v ./runme.sh ./Backup/oringinal-runme.sh
cp -v ./Start_Craft_Bukkit_Server.sh ./Backup/oringinal-Start_Craft_Bukkit_Server.sh
cp -v ./Start_Spigot_Server.sh ./Backup/oringinal-Start_Spigot_Server.sh
cp -v ./Start_Vanilla_Basic_Server.sh ./Backup/oringinal-Start_Vanilla_Basic_Server.sh
cp -avr ./bin ./Backup
cp -avr ./CraftBukkit_Server ./Backup
cp -avr ./Executable_Basic_Server ./Backup
cp -avr ./Java_Basic_Sever ./Backup
cp -avr ./logs ./Backup
cp -avr ./Spigot_Server ./Backup
cp -avr ./SupportDownloads ./Backup
echo
echo ----------------------------------
echo Updating
echo ----------------------------------
echo Checking out whats new...
echo
curl http://skits.businesscatalyst.com/assets/BukkitStarterKit/Updates/Updates.txt -o ./SupportDownloads/Updates.txt
cp -v ./SupportDownloads/Updates.txt ./bin/Updates.txt
cat ./bin/Updates.txt
read -p "Press enter to continue..."
echo
echo Downloading Updates...
echo
curl http://skits.businesscatalyst.com/assets/BukkitStarterKit/Updates/Patches.zip -o ./SupportDownloads/Patches.zip
echo
cp -v ./SupportDownloads/Patches.zip ./bin/Patches.zip
echo Unzipping...
echo
mkdir -v ./bin/Updates
mkdir -v ./bin/Extracts/UpdatePatches
unzip ./bin/Patches.zip -d ./bin/Extracts/UpdatePatches
unzip ./bin/Patches.zip -d ./bin/Updates
echo Done!

# Files:
# BuildToolsrester.sh
# bukkit_and_spigot_getter.sh
# Resetter.sh
# runme.sh
# StarterKit.sh
# StarterKit_no_bukkit.sh
# Updater_no_bin.sh
# Updatergetter.sh

echo Updateing
patch -b ./bin/BuildToolsrester.sh ./bin/Updates/BuildToolsreseterPatch.patch
patch -b ./bin/bukkit_and_spigot_getter.sh ./bin/Updates/bukkit_and_spigot_getter_Patch.patch
patch -b ./bin/Resetter.sh ./bin/Updates/ResetterPatch.patch
patch -b ./runme.sh ./bin/Updates/runmePatch.patch
patch -b ./bin/StarterKit.sh ./bin/Updates/StarterKitPatch.patch
patch -b ./bin/StarterKit_no_bukkit.sh ./bin/Updates/StarterKit_no_bukkitPatch.patch
patch -b ./bin/Updater_no_bin.sh ./bin/Updates/Updater_no_binPatch.patch
patch -b ./bin/Updatergetter.sh ./bin/Updates/UpdatergetterPatch.patch


echo ---------------------
echo Finished! Time taken:
time
echo ---------------------
echo Done!
cp ./BSKlog.log ./logs/`date +%y%m%d`.log