echo Bukkit Starter kit v1.1 BETA build 47 2>&1 | tee -a ./Updater.log
echo From http://skits.businesscatalyst.com 2>&1 | tee -a ./Updater.log
echo Issues? Vist http://skits.businesscatalyst.com 2>&1 | tee -a ./Updater.log
./bin/Updatergetter.sh