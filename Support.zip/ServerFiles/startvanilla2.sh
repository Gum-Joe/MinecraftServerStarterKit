cd ./Basic_Minecraft_Server
start.sh

