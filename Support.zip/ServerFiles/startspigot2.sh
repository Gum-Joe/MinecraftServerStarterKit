cd ./Spigot_Server
start.sh